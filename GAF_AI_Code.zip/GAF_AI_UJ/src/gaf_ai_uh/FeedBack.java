
package gaf_ai_uh;


public class FeedBack {
    private byte rating;
    private String comments;

    public FeedBack() {
        // Default constructor
    }

    public FeedBack(byte rating, String comments) {
        this.rating = rating;
        this.comments = comments;
    }

    public byte getRating() {
        return this.rating;
    }

    public String getComments() {
        return this.comments;
    }

    public void setRating(byte rating) {
        this.rating = rating;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getFeedback() {
        return "Rating: " + this.rating + ", Comments: " + this.comments;
    }
}