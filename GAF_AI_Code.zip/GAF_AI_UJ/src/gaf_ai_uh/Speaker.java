package gaf_ai_uh;

import java.util.List;


public class Speaker extends Attendee{

    // Private attributes
    private String bio;

    // Constructor with no arguments

    public Speaker(long ID, String name, String email, List<Session> sessions, String bio) {
        super(ID, name, email, sessions);
        this.bio = bio;
    }
 

    // Getter for bio
    public String getBio() {
        return bio;
    }

    // Setter for bio
    public void setBio(String bio) {
        this.bio = bio;
    }


    // Setter for sessionsOfSpeaker


    // Method to show speaker's information
    public void showSpeakerInfo() {
        System.out.println("Speaker Information:");
        System.out.println("Bio: " + bio);
        }
}
