
package gaf_ai_uh;

public class Certificate {
    private long certificateID = 1;
    private Session session;
    private Attendee attendee;

    public Certificate genrateCertificate() {
        // Implementation to generate a new certificate
        return this;
    }

    public Session getSession() {
        return this.session;
    }

    public Attendee getAttendee() {
        return this.attendee;
    }

    public long getCertificateID() {
        return this.certificateID;
    }

    public void setSession(Session session) {
        this.session = session;
    }

    public void setAttendee(Attendee attendee) {
        this.attendee = attendee;
    }

    public void setCertificateID(long certificateID) {
        this.certificateID = certificateID;
    }
}