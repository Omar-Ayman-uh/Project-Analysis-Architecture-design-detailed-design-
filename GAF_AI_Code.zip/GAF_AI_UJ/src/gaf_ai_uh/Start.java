
package gaf_ai_uh;

import java.text.SimpleDateFormat;
import java.util.Scanner;


public class Start {

public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Conference conference = null;

        while (true) {
            System.out.println("Please choose an action:");
            System.out.println("1. Create New Conference");
            System.out.println("2. Create Session in Conference");
            System.out.println("3. Show Conference Information");
            System.out.println("4. Add New conference Attendee");
            System.out.println("5. Exit");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline character

            switch (choice) {
                case 1:
                    System.out.println("Creating a new conference...");
                    conference = new Conference();
                    conference.inputConferenceData();
                    System.out.println("Conference created successfully!");
                    break;
                case 2:
                    if (conference != null) {
                        System.out.println("Creating a new session in the        conference...");
                        conference.createNewSession();
                    } else {
                        System.out.println("No conference available. Please create a conference first.");
                    }
                    break;
                case 3:
                    if (conference != null) {
                   System.out.println("Conference Information:");

                        SimpleDateFormat dateFormatter = new SimpleDateFormat("dd-MM-yyyy");
                        System.out.println("Name: " + conference.getName());
                        System.out.println("Start Date: " + dateFormatter.format(conference.getStartDate()));
                        System.out.println("End Date: " + dateFormatter.format(conference.getEndDate()));
                        System.out.println("Sessions:");
                        for (Session session : conference.getAllSessionsAvailableInConference()) {
                            System.out.println("- Session ID: " + session.getID());
                            System.out.println("  Session Name: " + session.getSessionName());
                            System.out.println("  Session Date: " + session.getSessionDate());
                            System.out.println("  Session Time: " + session.getSessionTime());
                            System.out.println("  Session Room: " + session.getSessionRoom());
                        }
                                System.out.println(conference.getAllAttendeesInConferenceList().size());
                        for (Attendee attendee : conference.getAllAttendeesInConferenceList()) {
                            System.out.println(attendee.getAttendeeInformation());
                        }
                        
                        
                    } else {
                        System.out.println("No conference available. Please create a conference first.");
                    }
                    break;
                case 4:
                    conference.addNewAttendee();
                    break;
                case 5:
                    System.out.println("Exiting the program...");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
            System.out.println();
        }
    }
    
}
