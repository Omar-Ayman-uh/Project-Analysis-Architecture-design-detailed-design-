
package gaf_ai_uh;

import java.util.ArrayList;
import java.util.Date;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class Conference {
    private String name;
    private Date startDate;
    private Date endDate;
    private ArrayList<Session> allSessionsAvailableInConference;
    private ArrayList<Attendee> allAttendeesInConferenceList;

    public ArrayList<Attendee> getAllAttendeesInConferenceList() {
        return allAttendeesInConferenceList;
    }

    public Conference() {
        this.allSessionsAvailableInConference = new ArrayList<>();
        this.allAttendeesInConferenceList = new ArrayList<>();
    }

    // Method to add a new attendee to the conference
    public void addNewAttendee() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter attendee ID: ");
        long attendeeID = scanner.nextLong();
        scanner.nextLine(); // Consume newline character

        System.out.print("Enter attendee name: ");
        String attendeeName = scanner.nextLine();

        System.out.print("Enter attendee email: ");
        String attendeeEmail = scanner.nextLine();

        // Initialize an empty session list
        List<Session> sessions = new ArrayList<>();

        // Optionally, let the user choose sessions the attendee will be part of
        System.out.println("Select sessions for this attendee:");
        for (Session session : allSessionsAvailableInConference) {
            System.out.println("Session ID: " + session.getID() + ", Session Name: " + session.getSessionName());
        }

        System.out.print("Enter session IDs (comma-separated): ");
        String[] sessionIDs = scanner.nextLine().split(",");
        for (String sessionIDStr : sessionIDs) {
            long sessionID = Long.parseLong(sessionIDStr.trim());
            Session session = findSessionByID(sessionID);
            if (session != null) {
                sessions.add(session);  // Add selected session to the attendee
            } else {
                System.out.println("Session ID " + sessionID + " not found.");
            }
        }

        // Create new Attendee object and add to the list of attendees
        Attendee newAttendee = new Attendee(attendeeID, attendeeName, attendeeEmail, sessions);
        newAttendee.getAttendeeInformation();
        this.allAttendeesInConferenceList.add(newAttendee);

        this.allAttendeesInConferenceList.get(0);

        System.out.println("New attendee added to the conference.");
    }

    // Method to find a session by its ID
    private Session findSessionByID(long sessionID) {
        for (Session session : allSessionsAvailableInConference) {
            if (session.getID() == sessionID) {
                return session;
            }
        }
        return null;
    }
    public void generate_certificate(long sessionID, long attendeeID) {
        // implementation to generate a certificate for the given session and attendee
    }

    public String getName() {
        return this.name;
    }

    public Date getStartDate() {
        return this.startDate;
    }

    public Date getEndDate() {
        return this.endDate;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public void createNewSession() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter session ID: ");
        long sessionID = scanner.nextLong();
        scanner.nextLine(); // Consume newline character

        System.out.print("Enter session name: ");
        String sessionName = scanner.nextLine();

        System.out.print("Enter session date (MM/dd/yyyy): ");
        String sessionDateStr = scanner.nextLine();
        Date sessionDate = new Date(sessionDateStr);

        System.out.print("Enter session time: e.g. (1 pm) ");
        String sessionTime = scanner.nextLine();

        System.out.print("Enter session room number (e.g. 1) : ");
        long sessionRoom = scanner.nextLong();
        scanner.nextLine(); // Consume newline character

        Session newSession = new Session(sessionID, sessionName, sessionDate, sessionTime, sessionRoom);
        this.allSessionsAvailableInConference.add(newSession);

        System.out.println("New session created and added to the conference.");
    }

    public ArrayList<Session> getAllSessionsAvailableInConference() {
        return allSessionsAvailableInConference;
    }
    
        public void inputConferenceData() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter conference name: ");
        String conferenceNameInput = scanner.nextLine();

        System.out.print("Enter conference start date (MM/dd/yyyy): ");
        String conferenceStartDateInput = scanner.nextLine();
        Date conferenceStartDate = new Date(conferenceStartDateInput);

        System.out.print("Enter conference end date (MM/dd/yyyy): ");
        String conferenceEndDateInput = scanner.nextLine();
        Date conferenceEndDate = new Date(conferenceEndDateInput);

        this.setName(conferenceNameInput);
        this.setStartDate(conferenceStartDate);
        this.setEndDate(conferenceEndDate);

        System.out.println("New conference created with the following details:");
        System.out.println("Name: " + this.getName());
        System.out.println("Start Date: " + this.getStartDate());
        System.out.println("End Date: " + this.getEndDate());
    }
    
}