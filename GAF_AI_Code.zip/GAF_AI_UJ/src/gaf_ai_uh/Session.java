
package gaf_ai_uh;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class Session {
    private long ID;
    private String sessionName;
    private Date sessionDate;
    private Object sessionTime;
    private long sessionRoom;
    private List<Attendee> attendeeList;
    private Speaker speaker;
    
    public Session(long ID, String sessionName, Date sessionDate, Object sessionTime, long sessionRoom) {
        this.ID = ID;
        this.sessionName = sessionName;
        this.sessionDate = sessionDate;
        this.sessionTime = sessionTime;
        this.sessionRoom = sessionRoom;
        this.attendeeList = attendeeList;
    }


    public void addAttendeeToSession(Attendee attendee) {
        this.attendeeList.add(attendee);
    }

      public String getSessionInformation() {
        StringBuilder sessionInfo = new StringBuilder();
        sessionInfo.append("Session ID: ").append(this.ID)
                   .append(", Session Name: ").append(this.sessionName)
                   .append(", Session Date: ").append(this.sessionDate)
                   .append(", Session Time: ").append(this.sessionTime)
                   .append(", Session Room: ").append(this.sessionRoom);

        if (speaker != null) {
            sessionInfo.append("\nSpeaker Information: ")
                       .append("\nBio: ").append(speaker.getBio());
        } else {
            sessionInfo.append("\nNo speaker assigned to this session.");
        }

        return sessionInfo.toString();
    }

    // Getter and Setter for speaker
    public Speaker getSpeaker() {
        return speaker;
    }

    public void setSpeaker(Speaker speaker) {
        this.speaker = speaker;
    }

    public long getID() {
        return this.ID;
    }

    public String getSessionName() {
        return this.sessionName;
    }

    public Date getSessionDate() {
        return this.sessionDate;
    }

    public Object getSessionTime() {
        return this.sessionTime;
    }

    public long getSessionRoom() {
        return this.sessionRoom;
    }

    public List<Attendee> getAttendeeList() {
        return this.attendeeList;
    }

    public void setSessionName(String sessionName) {
        this.sessionName = sessionName;
    }

    public void setSessionDate(Date sessionDate) {
        this.sessionDate = sessionDate;
    }

    public void setSessionTime(Object sessionTime) {
        this.sessionTime = sessionTime;
    }

    public void setSessionRoom(long sessionRoom) {
        this.sessionRoom = sessionRoom;
    }

    public void setAttendeeList(Attendee[] attendeeList) {
        this.attendeeList = Arrays.asList(attendeeList);
    }
}