
package gaf_ai_uh;

import java.util.List;
import java.util.Scanner;

public class Attendee {
    private long ID;
    private String name;
    private String email;
    private List<Session> sessions;

    public Attendee(long ID, String name, String email, List<Session> sessions) {
        this.ID = ID;
        this.name = name;
        this.email = email;
        this.sessions = sessions;
    }

    public void addSession(Session session) {
        this.sessions.add(session);
    }

    public void removeSession(Session session) {
        this.sessions.remove(session);
    }

    public long getID() {
        return this.ID;
    }

    public String getName() {
        return this.name;
    }

    public String getEmail() {
        return this.email;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setID(long ID) {
        this.ID = ID;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
 
// Method to display attendee information
public String getAttendeeInformation() {
    StringBuilder info = new StringBuilder();
    info.append("Attendee ID: ").append(this.ID)
        .append(", Name: ").append(this.name)
        .append(", Email: ").append(this.email)
        .append(", Sessions: ");

    if (sessions.isEmpty()) {
        info.append("No sessions assigned.");
    } else {
        for (Session session : sessions) {
            info.append("\n  - ").append(session.getSessionName());
        }
    }

    return info.toString();
}

    
}